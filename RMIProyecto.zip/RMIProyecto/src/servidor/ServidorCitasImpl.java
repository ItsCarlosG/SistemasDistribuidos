package servidor;

import cliente.ServidorCitas;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class ServidorCitasImpl extends UnicastRemoteObject implements ServidorCitas {

    private Map<String, String> pacientes;
    private Map<String, List<String>> citasPorPaciente;

    public ServidorCitasImpl() throws RemoteException {
        super();
        pacientes = new HashMap<>();
        citasPorPaciente = new HashMap<>();

        // Pacientes de prueba: usuario -> contraseña
        pacientes.put("juan", "1234");
        pacientes.put("darly", "abcd");
    }

    @Override
    public synchronized boolean loginPaciente(String usuario, String password) throws RemoteException {
        return pacientes.containsKey(usuario) && pacientes.get(usuario).equals(password);
    }

    @Override
    public synchronized boolean agendarCita(String paciente, String fecha) throws RemoteException {
        // Verificar que la cita no esté ocupada por nadie
        for (List<String> citas : citasPorPaciente.values()) {
            if (citas.contains(fecha)) {
                return false; // Ya está ocupada
            }
        }

        // Agregar cita si está libre
        citasPorPaciente.putIfAbsent(paciente, new ArrayList<>());
        citasPorPaciente.get(paciente).add(fecha);
        return true;
    }

    @Override
    public synchronized boolean cancelarCita(String paciente, String fecha) throws RemoteException {
        List<String> citas = citasPorPaciente.get(paciente);
        if (citas != null) {
            return citas.remove(fecha);
        }
        return false;
    }

    @Override
    public synchronized List<String> consultarCitas(String paciente) throws RemoteException {
        return new ArrayList<>(citasPorPaciente.getOrDefault(paciente, new ArrayList<>()));
    }
}
