package servidor;

import cliente.ServidorCitas;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServidorMain {
    public static void main(String[] args) {
        try {
            // Crear y exportar registro RMI en puerto 1099
            Registry registry = LocateRegistry.createRegistry(1099);

            ServidorCitas servidor = new ServidorCitasImpl();

            // Registrar el objeto remoto con nombre "ServidorCitas"
            registry.rebind("ServidorCitas", servidor);

            System.out.println("Servidor RMI iniciado y listo.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
