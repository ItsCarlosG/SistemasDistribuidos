package cliente;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface ServidorCitas extends Remote {
    boolean loginPaciente(String usuario, String password) throws RemoteException;
    boolean agendarCita(String paciente, String fecha) throws RemoteException;
    List<String> consultarCitas(String paciente) throws RemoteException;
    boolean cancelarCita(String paciente, String fecha) throws RemoteException;
}
