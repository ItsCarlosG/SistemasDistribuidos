package cliente;

import java.rmi.RemoteException;
import java.util.*;

public class ServidorCitasMock implements ServidorCitas {

    private Map<String, String> usuarios = new HashMap<>();
    private Map<String, List<String>> citas = new HashMap<>();

    public ServidorCitasMock() {
        usuarios.put("pedro", "1234");
        usuarios.put("maria", "ab123");
        usuarios.put("luisa", "2345");

        citas.put("pedro", new ArrayList<>());
        citas.put("maria", new ArrayList<>());
        citas.put("luisa", new ArrayList<>());
    }

    @Override
    public boolean loginPaciente(String usuario, String password) throws RemoteException {
        return usuarios.containsKey(usuario) && usuarios.get(usuario).equals(password);
    }

    @Override
    public boolean agendarCita(String paciente, String fecha) throws RemoteException {
        if (!citas.containsKey(paciente)) return false;

        List<String> lista = citas.get(paciente);
        if (lista.contains(fecha)) {
            return false;  // Ya existe esa cita
        }
        return lista.add(fecha);
    }

    @Override
    public List<String> consultarCitas(String paciente) throws RemoteException {
        return citas.getOrDefault(paciente, new ArrayList<>());
    }

    @Override
    public boolean cancelarCita(String paciente, String fecha) throws RemoteException {
        if (!citas.containsKey(paciente)) return false;
        return citas.get(paciente).remove(fecha);
    }
}
