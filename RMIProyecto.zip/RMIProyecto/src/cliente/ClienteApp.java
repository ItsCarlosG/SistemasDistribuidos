package cliente;

import javax.swing.*;

public class ClienteApp {
    public static void main(String[] args) {
        // Usar el mock para pruebas locales
        ServidorCitas servidor = new ServidorCitasMock();

        SwingUtilities.invokeLater(() -> {
            VentanaLogin ventana = new VentanaLogin(servidor);
            ventana.setVisible(true);
        });
    }
}
