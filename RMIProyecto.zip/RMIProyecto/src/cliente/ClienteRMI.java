package cliente;

import java.rmi.Naming;
import java.util.List;

public class ClienteRMI {
    private ServidorCitas servidor;

    public ClienteRMI() throws Exception {
        servidor = (ServidorCitas) Naming.lookup("rmi://localhost/ServidorCitas");
    }

    public boolean login(String usuario, String password) throws Exception {
        return servidor.loginPaciente(usuario, password);
    }

    public boolean agendarCita(String paciente, String fecha) throws Exception {
        return servidor.agendarCita(paciente, fecha);
    }

    public List<String> consultarCitas(String paciente) throws Exception {
        return servidor.consultarCitas(paciente);
    }

    public boolean cancelarCita(String paciente, String fecha) throws Exception {
        return servidor.cancelarCita(paciente, fecha);
    }
}
