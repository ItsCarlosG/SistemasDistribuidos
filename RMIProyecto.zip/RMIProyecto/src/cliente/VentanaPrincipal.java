package cliente;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.TimePicker;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class VentanaPrincipal extends JFrame {
    private ServidorCitas servidor;
    private String usuario;

    private DefaultListModel<String> modeloListaCitas;
    private JList<String> listaCitas;

    private JButton btnAgendar, btnCancelar;

    private DatePicker datePicker;
    private TimePicker timePicker;

    public VentanaPrincipal(ServidorCitas servidor, String usuario) {
        this.servidor = servidor;
        this.usuario = usuario;

        setTitle("Gestión de Citas - Paciente: " + usuario);
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panelFechaHora = new JPanel(new FlowLayout());

        // Instancia DatePicker y TimePicker
        datePicker = new DatePicker();
        timePicker = new TimePicker();

        panelFechaHora.add(new JLabel("Fecha:"));
        panelFechaHora.add(datePicker);

        panelFechaHora.add(new JLabel("Hora:"));
        panelFechaHora.add(timePicker);

        add(panelFechaHora, BorderLayout.NORTH);

        // Lista de citas
        modeloListaCitas = new DefaultListModel<>();
        listaCitas = new JList<>(modeloListaCitas);
        JScrollPane scroll = new JScrollPane(listaCitas);
        add(scroll, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();

        btnAgendar = new JButton("Agendar Cita");
        btnCancelar = new JButton("Cancelar Cita");

        panelBotones.add(btnAgendar);
        panelBotones.add(btnCancelar);

        add(panelBotones, BorderLayout.SOUTH);

        cargarCitas();

        btnAgendar.addActionListener(e -> agendarCita());
        btnCancelar.addActionListener(e -> cancelarCita());
    }

    private void cargarCitas() {
        try {
            modeloListaCitas.clear();
            for (String cita : servidor.consultarCitas(usuario)) {
                modeloListaCitas.addElement(cita);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar citas: " + ex.getMessage());
        }
    }

    private void agendarCita() {
        try {
            LocalDate fecha = datePicker.getDate();
            LocalTime hora = timePicker.getTime();

            // Validar campos vacíos
            if (fecha == null || hora == null) {
                JOptionPane.showMessageDialog(this, "Complete fecha y hora.");
                return;
            }

            LocalDateTime fechaHora = LocalDateTime.of(fecha, hora);
            LocalDateTime ahora = LocalDateTime.now();

            // Validar fecha y hora no pasada
            if (fechaHora.isBefore(ahora)) {
                JOptionPane.showMessageDialog(this, "Datos inválidos: la fecha y hora deben ser futuras.");
                return;
            }

            String cita = fechaHora.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

            boolean exito = servidor.agendarCita(usuario, cita);
            if (exito) {
                cargarCitas();
                JOptionPane.showMessageDialog(this, "Cita agendada exitosamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Ya existe una cita en ese horario.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al agendar cita: " + ex.getMessage());
        }
    }

    private void cancelarCita() {
        String citaSeleccionada = listaCitas.getSelectedValue();
        if (citaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una cita para cancelar.");
            return;
        }
        try {
            boolean exito = servidor.cancelarCita(usuario, citaSeleccionada);
            if (exito) {
                cargarCitas();
                JOptionPane.showMessageDialog(this, "Cita cancelada exitosamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo cancelar la cita.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al cancelar cita: " + ex.getMessage());
        }
    }
}
