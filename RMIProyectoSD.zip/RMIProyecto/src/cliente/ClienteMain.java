package cliente;

import javax.swing.SwingUtilities;

public class ClienteMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaLogin ventanaLogin = new VentanaLogin();
            ventanaLogin.setVisible(true);
        });
    }
}
