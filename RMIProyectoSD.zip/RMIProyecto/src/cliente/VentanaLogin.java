package cliente;

import shared.ServidorCitas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class VentanaLogin extends JFrame {
    private ServidorCitas servidor;

    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JCheckBox chkMostrarPassword;
    private JComboBox<String> comboRol;
    private JButton btnIngresar;
    private char echoCharOriginal;

    public VentanaLogin() {
        setTitle("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        // Componentes
        txtUsuario = new JTextField(20);
        txtPassword = new JPasswordField(20);
        echoCharOriginal = txtPassword.getEchoChar(); // Guardamos el carácter original
        chkMostrarPassword = new JCheckBox("Mostrar contraseña");
        comboRol = new JComboBox<>(new String[]{"Paciente", "Doctor"});
        btnIngresar = new JButton("Ingresar");

        // Panel de login
        JPanel panel = new JPanel(new GridLayout(5, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(new JLabel("Usuario:"));
        panel.add(txtUsuario);

        panel.add(new JLabel("Contraseña:"));
        panel.add(txtPassword);

        panel.add(new JLabel(""));  // espacio vacío para alinear el checkbox
        panel.add(chkMostrarPassword);

        panel.add(new JLabel("Rol:"));
        panel.add(comboRol);

        panel.add(new JLabel(""));  // espacio vacío
        panel.add(btnIngresar);

        add(panel);
        pack();
        setLocationRelativeTo(null);

        // Enter activa el botón
        getRootPane().setDefaultButton(btnIngresar);

        // Selección de texto al enfocar
        txtUsuario.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                txtUsuario.selectAll();
            }
        });

        txtPassword.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                txtPassword.selectAll();
            }
        });

        // Mostrar/ocultar contraseña
        chkMostrarPassword.addActionListener(e -> {
            txtPassword.setEchoChar(chkMostrarPassword.isSelected() ? (char) 0 : echoCharOriginal);
        });

        // Intentar conectar al servidor RMI al iniciar
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            servidor = (ServidorCitas) registry.lookup("ServidorCitas");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error al conectar con el servidor:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Acción del botón Ingresar
        btnIngresar.addActionListener(e -> {
            String usuario = txtUsuario.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();
            String rolSeleccionado = (String) comboRol.getSelectedItem();

            if (usuario.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese usuario y contraseña.");
                return;
            }

            if (servidor == null) {
                JOptionPane.showMessageDialog(this, "Servidor no disponible.");
                return;
            }

            try {
                boolean accesoValido = false;

                if ("Paciente".equals(rolSeleccionado)) {
                    accesoValido = servidor.loginPaciente(usuario, password);
                } else if ("Doctor".equals(rolSeleccionado)) {
                    accesoValido = servidor.loginDoctor(usuario, password);
                } else {
                    JOptionPane.showMessageDialog(this, "Rol no válido.");
                    return;
                }

                if (accesoValido) {
                    JOptionPane.showMessageDialog(this, "Ingreso exitoso.");

                    if ("Paciente".equals(rolSeleccionado)) {
                        VentanaPaciente vp = new VentanaPaciente(usuario, servidor);
                        vp.setVisible(true);
                    } else {
                        VentanaDoctor vd = new VentanaDoctor(servidor, usuario);
                        vd.setVisible(true);
                    }

                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Credenciales inválidas.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
    }

    public VentanaLogin(ServidorCitas servidor) {
        this();  // llama al constructor por defecto
        this.servidor = servidor;
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> new VentanaLogin().setVisible(true));
    }
}
