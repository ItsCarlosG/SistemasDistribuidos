package cliente;

import com.github.lgooddatepicker.components.DatePicker;

import javax.swing.*;
import java.awt.*;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import shared.ServidorCitas;

public class VentanaPaciente extends JFrame {
    private String usuario;
    private ServidorCitas servidor;

    private DatePicker datePicker;
    private JComboBox<String> comboHora;
    private JComboBox<String> comboDoctor;
    private JButton btnAgendar;
    private JButton btnCancelar;
    private JButton btnVerCitas;
    private JButton btnCerrarSesion;
    private JButton btnSalir;
    private JTextArea txtResultado;

    public VentanaPaciente(String usuario, ServidorCitas servidor) {
        this.usuario = usuario;
        this.servidor = servidor;

        setTitle("Ventana de Paciente - Usuario: " + usuario);
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelSuperior = new JPanel(new GridLayout(6, 2, 5, 5));

        // DatePicker
        datePicker = new DatePicker();
        datePicker.getSettings().setDateRangeLimits(LocalDate.now(), null); // Solo fechas desde hoy
        panelSuperior.add(new JLabel("📅 Fecha:"));
        panelSuperior.add(datePicker);

        // Combo Hora
        comboHora = new JComboBox<>(new String[]{
                "08:00", "09:00", "10:00", "11:00", "12:00",
                "13:00", "14:00", "15:00", "16:00"
        });
        panelSuperior.add(new JLabel("⏰ Hora:"));
        panelSuperior.add(comboHora);

        // Combo Doctor
        comboDoctor = new JComboBox<>(new String[]{
        "Dr.Perez", "Dr.Ricardo", "Dr.Pedro"
        });
        panelSuperior.add(new JLabel("👨‍⚕️ Doctor:"));
        panelSuperior.add(comboDoctor);

        // Botones principales
        btnAgendar = new JButton("Agendar Cita");
        btnCancelar = new JButton("Cancelar Cita");
        btnVerCitas = new JButton("Ver Citas");
        panelSuperior.add(btnAgendar);
        panelSuperior.add(btnCancelar);
        panelSuperior.add(btnVerCitas);

        // Botones adicionales
        btnCerrarSesion = new JButton("Cerrar Sesión");
        btnSalir = new JButton("Salir");
        panelSuperior.add(btnCerrarSesion);
        panelSuperior.add(btnSalir);

        add(panelSuperior, BorderLayout.NORTH);

        // Área de resultados
        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        txtResultado.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtResultado.setMargin(new Insets(10, 10, 10, 10));
        add(new JScrollPane(txtResultado), BorderLayout.CENTER);

        // Acciones de botones
        btnAgendar.addActionListener(e -> agendarCita());
        btnCancelar.addActionListener(e -> cancelarCita());
        btnVerCitas.addActionListener(e -> verCitas());
        btnCerrarSesion.addActionListener(e -> cerrarSesion());
        btnSalir.addActionListener(e -> System.exit(0));

        // Mostrar ventana
        setLocationRelativeTo(null);
        setVisible(true);
        datePicker.requestFocus();
    }

    private void agendarCita() {
        LocalDate fecha = datePicker.getDate();
        String hora = (String) comboHora.getSelectedItem();
        String doctor = (String) comboDoctor.getSelectedItem();

        if (fecha == null) {
            mostrarMensaje("⚠️ Debes seleccionar una fecha.");
            return;
        }
        if (hora == null) {
            mostrarMensaje("⚠️ Debes seleccionar una hora.");
            return;
        }
        if (doctor == null) {
            mostrarMensaje("⚠️ Debes seleccionar un doctor.");
            return;
        }

        LocalTime horaSeleccionada = LocalTime.parse(hora);
        LocalDate hoy = LocalDate.now();

        if (fecha.isBefore(hoy) || (fecha.equals(hoy) && horaSeleccionada.isBefore(LocalTime.now()))) {
            mostrarMensaje("❌ No puedes agendar una cita en el pasado.");
            return;
        }

        // Formato yyyy-MM-dd HH:mm
        String citaCompleta = fecha.format(DateTimeFormatter.ISO_LOCAL_DATE) + " " + hora;

        try {
            boolean exito = servidor.agendarCita(usuario, citaCompleta, doctor);
            if (exito) {
                mostrarMensaje("✅ Cita agendada con éxito para " + citaCompleta + " con " + doctor + ".");
            } else {
                mostrarMensaje("⚠️ No se pudo agendar la cita. Puede estar ocupada o ya tienes una cita en ese horario.");
            }
        } catch (RemoteException e) {
            mostrarMensaje("❌ Error al conectar con el servidor: " + e.getMessage());
        }
    }

    private void cancelarCita() {
    LocalDate fecha = datePicker.getDate();
    String hora = (String) comboHora.getSelectedItem();
    String doctor = (String) comboDoctor.getSelectedItem();

    if (fecha == null || hora == null || doctor == null) {
        mostrarMensaje("⚠️ Debes seleccionar una fecha, hora y doctor para cancelar.");
        return;
    }

    // Formato yyyy-MM-dd HH:mm
    String citaCompleta = fecha.format(DateTimeFormatter.ISO_LOCAL_DATE) + " " + hora;

    try {
        boolean exito = servidor.cancelarCita(usuario, doctor, citaCompleta);
        if (exito) {
            mostrarMensaje("✅ Cita cancelada con éxito: " + citaCompleta);
        } else {
            mostrarMensaje("⚠️ No se encontró una cita activa en esa fecha y hora con el doctor seleccionado.");
        }
    } catch (RemoteException e) {
        mostrarMensaje("❌ Error al conectar con el servidor: " + e.getMessage());
    }
}


    private void verCitas() {
        try {
            List<String> citas = servidor.consultarCitasDePaciente(usuario);
            if (citas.isEmpty()) {
                mostrarMensaje("📭 No tienes citas agendadas.");
            } else {
                StringBuilder sb = new StringBuilder("📒 Tus citas:\n\n");
                for (String cita : citas) {
                    sb.append("• ").append(cita).append("\n");
                }
                mostrarMensaje(sb.toString());
            }
        } catch (RemoteException e) {
            mostrarMensaje("❌ Error al obtener las citas: " + e.getMessage());
        }
    }

    private void cerrarSesion() {
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás segura de que deseas cerrar sesión?",
                "Cerrar Sesión",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (opcion == JOptionPane.YES_OPTION) {
            dispose();
            JOptionPane.showMessageDialog(null, "👋 Sesión cerrada. ¡Hasta pronto, " + usuario + "!");
            new VentanaLogin(servidor).setVisible(true);
        }
    }

    private void mostrarMensaje(String mensaje) {
        txtResultado.setText(mensaje);
    }
}
