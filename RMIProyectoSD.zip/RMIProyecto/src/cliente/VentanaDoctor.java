package cliente;

import javax.swing.*;
import java.awt.*;
import java.rmi.RemoteException;
import java.util.List;

import shared.ServidorCitas;

public class VentanaDoctor extends JFrame {
    private ServidorCitas servidor;
    private String usuario;

    private JButton btnVerCitas;
    private JButton btnConfirmar;
    private JButton btnRechazar;
    private JButton btnCerrarSesion;
    private JButton btnSalir;

    private JTextField txtFecha;
    private JTextField txtPaciente;

    private DefaultListModel<String> modeloListaCitas;
    private JList<String> listaCitas;

    public VentanaDoctor(ServidorCitas servidor, String usuario) {
        this.servidor = servidor;
        this.usuario = usuario;

        setTitle("Gestión de Citas - Doctor: " + usuario);
        setSize(600, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        txtFecha = new JTextField(15);
        txtPaciente = new JTextField(10);

        btnVerCitas = new JButton("Ver Mis Citas");
        btnConfirmar = new JButton("Confirmar Cita");
        btnRechazar = new JButton("Cancelar Cita");
        btnCerrarSesion = new JButton("Cerrar Sesión");
        btnSalir = new JButton("Salir");

        modeloListaCitas = new DefaultListModel<>();
        listaCitas = new JList<>(modeloListaCitas);
        listaCitas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Panel superior con campos y botones
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSuperior.add(new JLabel("Fecha (yyyy-MM-dd HH:mm):"));
        panelSuperior.add(txtFecha);
        panelSuperior.add(new JLabel("Paciente:"));
        panelSuperior.add(txtPaciente);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.add(btnVerCitas);
        panelBotones.add(btnConfirmar);
        panelBotones.add(btnRechazar);

        JPanel panelCerrar = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelCerrar.add(btnCerrarSesion);
        panelCerrar.add(btnSalir);

        JPanel panelContenedor = new JPanel(new BorderLayout());
        panelContenedor.add(panelSuperior, BorderLayout.NORTH);
        panelContenedor.add(panelBotones, BorderLayout.CENTER);
        panelContenedor.add(panelCerrar, BorderLayout.SOUTH);

        JScrollPane scrollLista = new JScrollPane(listaCitas);

        setLayout(new BorderLayout());
        add(panelContenedor, BorderLayout.NORTH);
        add(scrollLista, BorderLayout.CENTER);

        // Eventos
        btnVerCitas.addActionListener(e -> verMisCitas());
        btnConfirmar.addActionListener(e -> confirmarCita());
        btnRechazar.addActionListener(e -> rechazarCita());
        btnCerrarSesion.addActionListener(e -> cerrarSesion());
        btnSalir.addActionListener(e -> salirAplicacion());

        // Al seleccionar una cita, extraer fecha y paciente y llenar los campos
        listaCitas.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String seleccion = listaCitas.getSelectedValue();
                if (seleccion != null) {
                   
                    try {
                        String paciente = "";
                        String fecha = "";

                        
                        if (seleccion.contains("Paciente:") && seleccion.contains("Fecha:")) {
                            int idxPaciente = seleccion.indexOf("Paciente:") + 9;
                            int idxFecha = seleccion.indexOf("Fecha:");
                            paciente = seleccion.substring(idxPaciente, idxFecha).trim().replace(",", "");
                            fecha = seleccion.substring(idxFecha + 6).trim();
                        } else {
                            
                            String[] partes = seleccion.split("-");
                            if (partes.length == 2) {
                                fecha = partes[0].trim();
                                paciente = partes[1].trim();
                            }
                        }

                        txtPaciente.setText(paciente);
                        txtFecha.setText(fecha);
                    } catch (Exception ex) {
                        txtPaciente.setText("");
                        txtFecha.setText("");
                    }
                }
            }
        });
    }

    private void verMisCitas() {
    try {
        List<String> citas = servidor.consultarCitasDelDoctor(usuario.trim().toLowerCase());
        System.out.println("Citas recibidas: " + citas);
        modeloListaCitas.clear();
        if (citas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tienes citas asignadas.", "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            for (String cita : citas) {
                modeloListaCitas.addElement(cita);
            }
        }
    } catch (RemoteException e) {
        mostrarError("Error al conectar con el servidor: " + e.getMessage());
        e.printStackTrace();
    }
}


    private void confirmarCita() {
        String fecha = txtFecha.getText().trim();
        String paciente = txtPaciente.getText().trim().toLowerCase();
        String doctor = usuario.trim().toLowerCase();

        if (fecha.isEmpty() || paciente.isEmpty()) {
            mostrarError("Por favor selecciona una cita para confirmar.");
            return;
        }
        if (!validarFormatoFecha(fecha)) {
            mostrarError("Formato de fecha inválido. Usa yyyy-MM-dd HH:mm");
            return;
        }
        try {
            if (servidor.marcarCitaAtendida(paciente, doctor, fecha)) {
                JOptionPane.showMessageDialog(this, "✅ Cita confirmada para " + fecha + " del paciente " + paciente);
                limpiarCampos();
                verMisCitas();  // refrescar lista
            } else {
                mostrarError("No se pudo confirmar la cita. Verifica los datos o si la cita no te pertenece.");
            }
        } catch (RemoteException e) {
            mostrarError("Error al conectar con el servidor: " + e.getMessage());
        }
    }

    private void rechazarCita() {
        String fecha = txtFecha.getText().trim();
        String paciente = txtPaciente.getText().trim().toLowerCase();
        String doctor = usuario.trim().toLowerCase();

        if (fecha.isEmpty() || paciente.isEmpty()) {
            mostrarError("Por favor selecciona una cita para cancelar.");
            return;
        }
        if (!validarFormatoFecha(fecha)) {
            mostrarError("Formato de fecha inválido. Usa yyyy-MM-dd HH:mm");
            return;
        }
        try {
            if (servidor.cancelarCita(paciente, doctor, fecha)) {
                JOptionPane.showMessageDialog(this, "✅ Cita cancelada para " + fecha + " del paciente " + paciente);
                limpiarCampos();
                verMisCitas();  // refrescar lista
            } else {
                mostrarError("No se pudo cancelar la cita. Verifica los datos o si la cita no te pertenece.");
            }
        } catch (RemoteException e) {
            mostrarError("Error al conectar con el servidor: " + e.getMessage());
        }
    }

    private void cerrarSesion() {
        int opcion = JOptionPane.showConfirmDialog(this, "¿Deseas cerrar sesión?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            this.dispose();
            JOptionPane.showMessageDialog(null, "👋 Sesión cerrada. ¡Hasta pronto, " + usuario + "!");
            new VentanaLogin(servidor).setVisible(true);
        }
    }

    private void salirAplicacion() {
        int opcion = JOptionPane.showConfirmDialog(this, "¿Deseas salir de la aplicación?", "Confirmar salida", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private boolean validarFormatoFecha(String fecha) {
        return fecha.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}");
    }

    private void limpiarCampos() {
        txtFecha.setText("");
        txtPaciente.setText("");
        listaCitas.clearSelection();
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
