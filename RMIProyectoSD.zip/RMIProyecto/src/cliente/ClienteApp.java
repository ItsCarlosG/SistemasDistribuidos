package cliente;

import javax.swing.*;
import shared.ServidorCitas;
import servidor.ServidorCitasMock;

public class ClienteApp {
    public static void main(String[] args) {
        try {
           
            ServidorCitas servidor = new ServidorCitasMock();

            SwingUtilities.invokeLater(() -> {
                VentanaLogin ventana = new VentanaLogin(servidor);
                ventana.setVisible(true);
            });
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al iniciar el cliente: " + e.getMessage());
        }
    }
}
