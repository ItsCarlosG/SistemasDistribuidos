package cliente;

import shared.ServidorCitas;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClienteRMI {

    private static ServidorCitas servidor;

    public static ServidorCitas obtenerServidor() {
        if (servidor == null) {
            try {
                String host = "localhost"; 
                Registry registry = LocateRegistry.getRegistry(host, 1099);
                servidor = (ServidorCitas) registry.lookup("ServidorCitas");
                System.out.println("✅ Conectado al servidor RMI en " + host);
            } catch (Exception e) {
                System.err.println("❌ Error al conectar al servidor RMI: " + e.getMessage());
            }
        }
        return servidor;
    }

    public static void main(String[] args) {
        ServidorCitas servidor = ClienteRMI.obtenerServidor();
        if (servidor != null) {
            System.out.println("✔️ Conexión establecida con el servidor.");
        } else {
            System.out.println("⚠️ No se pudo conectar con el servidor RMI.");
        }
    }
}
