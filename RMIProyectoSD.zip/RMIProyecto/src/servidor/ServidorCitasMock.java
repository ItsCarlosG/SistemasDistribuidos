package servidor;

import shared.ServidorCitas;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class ServidorCitasMock extends UnicastRemoteObject implements ServidorCitas {

    private static class Cita {
        String paciente;
        String fechaHora;
        String doctor;
        String estado;

        Cita(String paciente, String fechaHora, String doctor) {
            this.paciente = paciente;
            this.fechaHora = fechaHora;
            this.doctor = doctor;
            this.estado = "PROGRAMADA";
        }

        @Override
        public String toString() {
            return fechaHora + " con " + doctor + " - Estado: " + estado;
        }

        public String resumen() {
            return paciente + " - " + toString();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Cita cita = (Cita) o;
            return paciente.equals(cita.paciente) &&
                   fechaHora.equals(cita.fechaHora) &&
                   doctor.equals(cita.doctor);
        }

        @Override
        public int hashCode() {
            return Objects.hash(paciente, fechaHora, doctor);
        }
    }

    private Map<String, String> pacientes;
    private Map<String, String> doctores;
    private List<Cita> citas;

    public ServidorCitasMock() throws RemoteException {
        super();

        pacientes = new HashMap<>();
        doctores = new HashMap<>();
        citas = new ArrayList<>();

        pacientes.put("Luis", "Lui$2023a");
        pacientes.put("Pedro", "P3dr0#Ab");
        pacientes.put("Mariana", "M@riAna9!");

        doctores.put("Dr.Perez", "DrP3r#z7");
        doctores.put("Dr.Ricardo", "Ric@rdo45A");
        doctores.put("Dr.Pedro", "Dr.P3d!0x");
    }

    @Override
    public boolean loginPaciente(String usuario, String password) throws RemoteException {
        return pacientes.containsKey(usuario) && pacientes.get(usuario).equals(password);
    }

    @Override
    public boolean loginDoctor(String usuario, String password) throws RemoteException {
        return doctores.containsKey(usuario) && doctores.get(usuario).equals(password);
    }

    @Override
    public synchronized boolean agendarCita(String paciente, String fechaHora, String doctor) throws RemoteException {
        Cita nuevaCita = new Cita(paciente, fechaHora, doctor);

        for (Cita c : citas) {
            if (c.equals(nuevaCita) && c.estado.equals("PROGRAMADA")) return false;
            if (c.doctor.equals(doctor) && c.fechaHora.equals(fechaHora) && c.estado.equals("PROGRAMADA")) return false;
            if (c.paciente.equals(paciente) && c.fechaHora.equals(fechaHora) && c.estado.equals("PROGRAMADA")) return false;
        }

        citas.add(nuevaCita);
        return true;
    }

    @Override
    public synchronized List<String> consultarCitas(String usuario) throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            if (c.paciente.equals(usuario) && c.estado.equals("PROGRAMADA")) {
                resultado.add(c.toString());
            }
        }
        return resultado;
    }

    @Override
    public synchronized List<String> consultarTodasLasCitas() throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            resultado.add(c.resumen());
        }
        return resultado;
    }

    @Override
    public synchronized List<String> consultarCitasDePaciente(String paciente) throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            if (c.paciente.equals(paciente)) {
                resultado.add(c.fechaHora + " con el doctor " + c.doctor + " - Estado: " + c.estado);
            }
        }
        return resultado;
    }

    @Override
    public synchronized boolean cancelarCita(String paciente, String doctor, String fechaHora) throws RemoteException {
        for (Cita c : citas) {
            if (c.paciente.equals(paciente) && c.doctor.equals(doctor) && c.fechaHora.equals(fechaHora)) {
                c.estado = "CANCELADA";
                return true;
            }
        }
        return false;
    }

    @Override
    public synchronized boolean marcarCitaAtendida(String paciente, String doctor, String fechaHora) throws RemoteException {
        for (Cita c : citas) {
            if (c.paciente.equals(paciente) && c.doctor.equals(doctor) && c.fechaHora.equals(fechaHora)) {
                c.estado = "ATENDIDA";
                return true;
            }
        }
        return false;
    }

    @Override
    public synchronized List<String> consultarCitasDelDoctor(String doctor) throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            if (c.doctor.equals(doctor) && c.estado.equals("PROGRAMADA")) {
                resultado.add(c.paciente + " - " + c.fechaHora + " - Estado: " + c.estado);
            }
        }
        return resultado;
    }

    @Override
    public List<String> obtenerDoctores() throws RemoteException {
        return new ArrayList<>(doctores.keySet());
    }
}
