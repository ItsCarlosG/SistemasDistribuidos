package servidor;

import java.io.Serializable;

public class Cita implements Serializable {
    public String paciente;
    public String doctor;
    public String fechaHora;
    public String estado; // PROGRAMADA, CANCELADA, ATENDIDA

    public Cita(String paciente, String doctor, String fechaHora, String estado) {
        this.paciente = paciente;
        this.doctor = doctor;
        this.fechaHora = fechaHora;
        this.estado = estado;
    }

    @Override
    public String toString() {
        return paciente + "::" + doctor + "::" + fechaHora + "::" + estado;
    }

    public static Cita desdeTexto(String linea) {
        String[] partes = linea.split("::");
        if (partes.length == 4) {
            return new Cita(partes[0], partes[1], partes[2], partes[3]);
        }
        return null;
    }
}
