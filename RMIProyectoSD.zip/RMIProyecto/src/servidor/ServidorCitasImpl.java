package servidor;

import shared.ServidorCitas;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ServidorCitasImpl extends UnicastRemoteObject implements ServidorCitas {

    private final List<Cita> citas = new ArrayList<>();
    private final Map<String, String> usuariosPacientes = new HashMap<>();
    private final Map<String, String> usuariosDoctores = new HashMap<>();
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    protected ServidorCitasImpl() throws RemoteException {
        super();
        usuariosPacientes.put("Luis", "Lui$2023a");
        usuariosPacientes.put("Pedro", "P3dr0#Ab");
        usuariosPacientes.put("Mariana", "M@riAna9!");
        usuariosDoctores.put("Dr.Perez", "DrP3r#z7");
        usuariosDoctores.put("Dr.Ricardo", "Ric@rdo45A");
        usuariosDoctores.put("Dr.Pedro", "Dr.P3d!0x");
    }

    @Override
    public boolean loginPaciente(String usuario, String password) throws RemoteException {
        return password.equals(usuariosPacientes.get(usuario));
    }

    @Override
    public boolean loginDoctor(String usuario, String password) throws RemoteException {
        return password.equals(usuariosDoctores.get(usuario));
    }

    @Override
    public synchronized boolean agendarCita(String paciente, String fechaHora, String doctor) throws RemoteException {
        LocalDateTime fecha;
        try {
            fecha = LocalDateTime.parse(fechaHora.trim(), formatter);
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido: " + fechaHora);
            return false;
        }

        for (Cita c : citas) {
            LocalDateTime cFecha = c.fechaHora.withSecond(0).withNano(0);
            LocalDateTime fFecha = fecha.withSecond(0).withNano(0);
            if (c.estado.equals("PROGRAMADA") && cFecha.equals(fFecha)) {
                if (c.doctor.equalsIgnoreCase(doctor.trim())) return false;
                if (c.paciente.equalsIgnoreCase(paciente.trim())) return false;
            }
        }

        citas.add(new Cita(paciente.trim(), doctor.trim(), fecha, "PROGRAMADA"));
        System.out.println("Cita agendada: " + paciente + ", " + doctor + ", " + fechaHora);
        return true;
    }

    @Override
    public synchronized List<String> consultarCitas(String usuario) throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            if (c.paciente.equalsIgnoreCase(usuario.trim()) && !c.estado.equals("CANCELADA")) {
                resultado.add(c.toString());
            }
        }
        return resultado;
    }

    @Override
    public synchronized List<String> consultarTodasLasCitas() throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            resultado.add(c.paciente + " - " + c.toString());
        }
        return resultado;
    }

    @Override
    public synchronized List<String> consultarCitasDePaciente(String paciente) throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            if (c.paciente.equalsIgnoreCase(paciente.trim()) && !c.estado.equals("CANCELADA")) {
                resultado.add(c.fechaHora.format(formatter) + " con el doctor " + c.doctor + " (" + c.estado + ")");
            }
        }
        return resultado;
    }

    @Override
    public synchronized List<String> consultarCitasDelDoctor(String doctor) throws RemoteException {
        List<String> resultado = new ArrayList<>();
        for (Cita c : citas) {
            if (c.doctor.equalsIgnoreCase(doctor.trim()) && !c.estado.equals("CANCELADA")) {
                resultado.add(c.fechaHora.format(formatter) + " con el paciente " + c.paciente + " (" + c.estado + ")");
            }
        }
        return resultado;
    }

    @Override
    public synchronized boolean marcarCitaAtendida(String paciente, String doctor, String fechaHora) throws RemoteException {
        try {
            LocalDateTime fecha = LocalDateTime.parse(fechaHora.trim(), formatter);
            for (Cita c : citas) {
                if (c.paciente.equalsIgnoreCase(paciente.trim()) &&
                    c.doctor.equalsIgnoreCase(doctor.trim()) &&
                    c.fechaHora.withSecond(0).withNano(0).equals(fecha.withSecond(0).withNano(0)) &&
                    c.estado.equals("PROGRAMADA")) {
                    c.estado = "ATENDIDA";
                    return true;
                }
            }
        } catch (Exception e) {
            System.out.println("Error parseando fecha en marcarCitaAtendida: " + e.getMessage());
        }
        return false;
    }

    @Override
    public synchronized boolean cancelarCita(String paciente, String doctor, String fechaHora) throws RemoteException {
        try {
            LocalDateTime fecha = LocalDateTime.parse(fechaHora.trim(), formatter);
            for (Cita c : citas) {
                if (c.paciente.equalsIgnoreCase(paciente.trim()) &&
                    c.doctor.equalsIgnoreCase(doctor.trim()) &&
                    c.fechaHora.withSecond(0).withNano(0).equals(fecha.withSecond(0).withNano(0)) &&
                    c.estado.equals("PROGRAMADA")) {
                    c.estado = "CANCELADA";
                    return true;
                }
            }
        } catch (Exception e) {
            System.out.println("Error parseando fecha en cancelarCita: " + e.getMessage());
        }
        return false;
    }

    @Override
    public List<String> obtenerDoctores() throws RemoteException {
        return new ArrayList<>(usuariosDoctores.keySet());
    }

    private static class Cita {
        String paciente;
        String doctor;
        LocalDateTime fechaHora;
        String estado;

        Cita(String paciente, String doctor, LocalDateTime fechaHora, String estado) {
            this.paciente = paciente;
            this.doctor = doctor;
            this.fechaHora = fechaHora;
            this.estado = estado;
        }

        @Override
        public String toString() {
            return fechaHora.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
                    " con " + doctor + " - Estado: " + estado;
        }
    }

    public static void main(String[] args) {
        try {
            ServidorCitasImpl obj = new ServidorCitasImpl();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("ServidorCitas", obj);
            System.out.println("Servidor RMI listo.");
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
}
