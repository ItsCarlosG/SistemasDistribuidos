package shared;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface ServidorCitas extends Remote {
    boolean loginPaciente(String usuario, String password) throws RemoteException;
    boolean loginDoctor(String usuario, String password) throws RemoteException;
    boolean agendarCita(String paciente, String fechaHora, String doctor) throws RemoteException;
    List<String> consultarCitas(String usuario) throws RemoteException;
    List<String> consultarTodasLasCitas() throws RemoteException;
    boolean marcarCitaAtendida(String paciente, String doctor, String fechaHora) throws RemoteException;
    boolean cancelarCita(String paciente, String doctor, String fechaHora) throws RemoteException;
    List<String> consultarCitasDePaciente(String paciente) throws RemoteException;
    List<String> consultarCitasDelDoctor(String doctor) throws RemoteException;

    List<String> obtenerDoctores() throws RemoteException;
}
